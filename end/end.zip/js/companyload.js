const loaddata = () => {
    const tablediv = document.getElementById('companyshow');
    
}