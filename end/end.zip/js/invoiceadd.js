const addtoinvoice = () => {
    const object = document.getElementsByClassName('billing-list');
    console.log(object);
}